public class Droid extends Sprite {

	private static String droidImage = "res/basic-enemy.png";

	public Droid(float x, float y) {
		super(droidImage, x, y);
		// TODO Auto-generated constructor stub
	}
}
